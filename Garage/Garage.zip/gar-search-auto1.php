<head>
    <meta name
    "autoher" content = "King Luis Manuel">
    <meta charset="utf-8">
</head>
<body>
<h1>Garage zoek auto Id</h1>
<p>Dit formulier zoekt een autin in de database garage.</p>
<form action = "gar-search-auto2.php" method="post"> Welke autinId Zukt u?
<input type = "text" name = "klantidvak"> <br />
<input type ="submit">
    </form>
</body>