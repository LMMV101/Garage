<head>
    <meta name
    "autoher" content = "King Luis Manuel">
    <meta charset="utf-8">
</head>

<body>
<h1> Delete klant 1</h1>
<p> Dit form zoekt een klant om te verwijderen.</p>
<form action ="gar-delete-klant2.php" method ="post">
    welk klantid wilt u verwijderen?
    <input type = "text" name = "klantidvak"> <br/>
    <input type ="submit"></form></body>