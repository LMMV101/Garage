<head>
    <meta name
    "autoher" content = "King Luis Manuel">
    <meta charset="utf-8">
</head>
<body>
<h1> garage create klantin</h1>
<p>
    Dit form wordt gebruikt om klantGegevens in te voeren.
</p>
<form action="gar-create-klant2.php" method="post">
    klantnaam: <input type="text" name="klantnaamvak"> <br/>
    klantadres: <input type="text" name="klantadresvak"><br/>
    klantpostcode: <input type="text" name="klantpostcodevak"><br/>
    klantplaats: <input type="text" name="klantplaatsvak"><br/>
    <input type="submit">

</form>

</body>