<head>
    <meta name
    "autoher" content = "King Luis Manuel">
    <meta charset="utf-8">
</head>
<body>
<h1>Garage update autin 1</h1>
<p> Dit form wort gebruikt om klant info te veranderen</p>
<form action="gar-update-auto2.php" method="post">
    welke klant wijzigen?
    <input type = "text" name="klantidvak"> <br />
    <input type ="submit">
    </form>
</body>