<head>
    <meta name
    "autoher" content = "King Luis Manuel">
    <meta charset="utf-8">
</head>
<body>
<h1> garage ipdate Autin 2</h1>
<p> Dit form wordt gebruikt om info the wijzigen</p>
<?php

    $klantid = $_POST["klantidvak"];
    require_once "gar-connect.php";
    $klanten = $conn->prepare("select 
                                      Autokenteken,
                                      Automerk,
                                      autotype,
                                      autokmstand,
                                      klantid
                                      from auto
                                      where klantid = :klantid");
    
    $klanten->execute(["klantid" => $klantid]);
    
    echo "<form action='gar-update-klant3.php' method ='post'>";
    foreach($klanten as $klant)
    {
    echo"klantnaam: <input type= 'text'";
    echo"name ='Autokentekenvak'";
    echo "value = '".$klant["Autokenteken"]. "'";
    echo "><br />";
    
    echo"klantadres: <input type = 'text' ";
    echo "name = 'Automerkvak' ";
    echo "value= '".$klant["Automerk"]."'";
    echo "><br />";
    
      echo"klantpostcode: <input type = 'text' ";
    echo "name = 'autotypevak' ";
    echo "value= '".$klant["autotype"]."'";
    echo "><br />";
    
      echo"klantplaats: <input type = 'text' ";
    echo "name = 'autokmstandvak ";
    echo "value= '".$klant["autokmstand"]."'";
    echo "><br />";
        
        echo "klantid:" . $klant["klantid"];
    echo "<input type = 'hidden' name='klantidvak'";
    echo " value='".$klant["klantid"]."''>br />";
    
                                      }
                              
    echo "<input type ='submit'>";
    echo"</form>"
        ?>
    </body>
                 